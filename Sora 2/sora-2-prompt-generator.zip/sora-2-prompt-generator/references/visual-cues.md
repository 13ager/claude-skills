# Visual Cues and Techniques

## Style Anchors

Style is the most powerful lever for guiding the model. It frames all other choices.

**Era/Genre Examples:**
- 1970s film
- 90s documentary
- IMAX scene
- 16mm B&W
- Hand-painted animation
- Stop-motion feel
- Anamorphic 2.39:1
- Digital cinema
- VHS tape aesthetic

## Camera Framing

**Shot Types:**
- Wide establishing shot
- Medium shot
- Medium close-up
- Close-up
- Extreme close-up
- Over-the-shoulder
- Two-shot
- Aerial wide shot

**Angles:**
- Eye level
- Slight angle from behind
- Low angle
- High angle
- Dutch angle
- Bird's eye view
- Worm's eye view

**Camera Movement:**
- Static camera
- Slow push-in
- Pull-out/reveal
- Dolly left/right
- Slow pan
- Tilt up/down
- Handheld ENG camera
- Steadicam follow
- Crane shot

## Lighting Techniques

Be specific about quality and direction rather than generic descriptions.

**Quality:**
- Soft/diffused
- Hard/direct
- Volumetric
- Dappled
- Rim light
- Backlighting
- Natural/practical

**Sources:**
- Window light
- Overhead lamp
- Golden hour sun
- Tungsten bounce
- Fairy lights
- Sodium vapor
- Candlelight
- Screen glow

**Temperature:**
- Warm amber
- Cool blue
- Neutral daylight
- Mixed temperature

## Color Palette

Name 3-5 specific colors to anchor the palette.

**Examples:**
- Amber, cream, walnut, teal
- Navy, silver, white, rust
- Forest green, ochre, burgundy
- Slate gray, blush pink, ivory

## Motion Control

Keep movements simple and specific.

**Weak:** "Person moves quickly"
**Strong:** "Cyclist pedals three times, brakes, and stops"

**Weak:** "Actor walks across room"
**Strong:** "Actor takes four steps, pauses at window, pulls curtain"

**Action Structure:**
- One camera move per shot
- One primary subject action
- Count/beat the action for timing
- Describe in sequential beats

## Depth of Field

- Shallow DOF (subject isolated, background soft)
- Deep focus (everything sharp)
- Rack focus (shift focus between subjects)

## Film Characteristics

**Grain:**
- Fine grain
- Heavy grain
- Digital clean

**Lens Effects:**
- Anamorphic flares
- Spherical bokeh
- Black Pro-Mist filter
- Gate weave
- Halation on highlights
- Chromatic aberration
- Vignette

## Sound Design Notes

Even for silent shots, suggest audio texture:

**Ambient:**
- Distant traffic hiss
- Wind through trees
- Rain patter
- Clock ticking
- Fabric rustling

**Action:**
- Footsteps
- Door creak
- Glass clink
- Papers shuffle
- Breathing

## Weak vs Strong Prompts

| Weak | Strong |
|------|--------|
| Beautiful street at night | Wet asphalt, zebra crosswalk, neon signs reflected in puddles |
| Person moves quickly | Cyclist pedals three times, brakes, stops |
| Cinematic look | Anamorphic lens, shallow DOF, volumetric light through window |
| Brightly lit room | Soft window light with warm lamp fill, cool rim from hallway |
| Nice atmosphere | Gentle mist, amber streetlights, distant train horn |
