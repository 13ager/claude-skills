# Short Prompt Examples

Short prompts give the model creative freedom while maintaining core direction. Use when you want surprising variations and unexpected interpretations.

## Documentary Style

> In a 90s documentary-style interview, an old Swedish man sits in a study and says, "I still remember when I was young."

- `90s documentary` sets the style
- `an old Swedish man sits in a study` describes subject/setting
- `and says, ...` describes dialogue
- Details left open (time of day, outfit, tone) will be improvised by the model

## Nature Scene

> A red panda climbs a moss-covered tree in morning mist, pauses on a branch, and looks directly at camera.

- Single subject, single location
- One clear action sequence
- Environmental detail (moss, mist) without over-specifying

## Urban Moment

> Commuter rushes through Tokyo station at dawn, briefcase swinging, steam rising from platform vents.

- Style implied through location (Tokyo)
- Time of day specified (dawn)
- Simple action with environmental texture

## Character Portrait

> Young chef in white apron tastes soup from wooden spoon, closes eyes, adds pinch of salt.

- Clear subject and costume
- Simple three-beat action sequence
- Location implied through context

## Abstract/Atmospheric

> Sunlight filters through stained glass, casting colored patterns that slowly shift across a stone floor.

- Focus on light and atmosphere
- Motion is gentle and natural
- Minimal specificity allows model creativity
