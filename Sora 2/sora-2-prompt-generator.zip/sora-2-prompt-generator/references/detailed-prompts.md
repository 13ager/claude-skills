# Detailed Prompt Examples

Detailed prompts maximize control and consistency. Use when you need precise cinematography, specific look/feel, or controlled production values.

## Example 1: Animated Workshop Scene

**Style:** Hand-painted hybrid animation, soft textures, warm lighting, tactile stop-motion feel. Cozy, mechanical charm. Workshop with robot on bench, glowing eyes, nervous; rain patters, clock ticks.

**Cinematography:** medium close-up, slow push-in, gentle parallax; 35mm lens, shallow DOF.

**Lighting:** warm overhead, cool spill from window.

**Mood:** gentle, whimsical, suspenseful.

**Actions:**
- Robot taps bulb, sparks.
- Flinches, eyes widen.
- Bulb tumbles, caught in time.
- Puff of steam; pride.

**Dialogue:**
Robot (quietly): "Almost lost it… but I got it!"

**Background:** rain, ticking, bulb sizzle.

---

## Example 2: 1970s Rooftop Romance

**Style:** 1970s romantic drama, shot on 35mm film. Soft focus, warm halation, gate weave, grain, vignette. Tenement rooftop, laundry sways, woman dances in flowing red dress, partner claps, city noise below.

**Cinematography:** medium-wide, slow dolly-in, eye level; 40mm spherical, shallow focus.

**Lighting:** golden hour, tungsten bounce, fairy bulbs.

**Mood:** nostalgic, tender, cinematic.

**Actions:**
- Dress flares, sunlight.
- Woman: "See? Even the city dances with us tonight."
- Partner catches hand, dips her.
- Man: "Only because you lead."
- Sheets veil and part skyline.

**Background:** wind, fabric, music, street noise.

---

## Example 3: Ultra-Detailed Commuter Platform

**Format & Look:**
- Duration: 4s
- 180° shutter
- Digital capture emulating 65mm photochemical contrast
- Fine grain, subtle halation on speculars
- Lenses: 32mm / 50mm spherical, Black Pro-Mist

**Grade:**
- Clean morning sunlight
- Amber lift, neutrals, teal shadows
- Soft blacks

**Lighting:**
- Natural sunlight camera left
- Ultrabounce silver
- Sodium platform lights

**Atmosphere:**
- Gentle mist
- Train exhaust

**Location:**
- Urban commuter platform, dawn

**Wardrobe:**
- Navy coat traveler
- Extras in muted tones

**Sound:**
- Rail screech
- Train brakes hiss
- Distant announcement
- Footsteps

**Shot 1:**
Wide establishing, eye level, platform edge. Commuter enters frame left, four steps toward camera, stops at yellow line. Train arrives, doors open. Commuter boards. Camera static.

---

## Template for Detailed Prompts

Use this structure when you need maximum control:

**Style:** [Era/genre/format, visual texture, film stock/capture method]

**Cinematography:** [Shot type, camera movement, lens, depth of field]

**Lighting:** [Quality, direction, color temperature, sources]

**Mood:** [Emotional tone, atmosphere]

**Actions:**
- [Beat 1 with specific count/timing]
- [Beat 2]
- [Beat 3]

**Dialogue:**
[Character]: "[Line]"
[Character 2]: "[Response]"

**Background:** [Ambient sound, environmental details]
