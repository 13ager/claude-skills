# Perplexity Prompt Templates

Quick-reference templates for common professional use cases. Copy and customize as needed.

## Education

**Lesson planning:**
```
Context: [Grade level/subject area]
Task: Create a [timeframe] lesson plan on [topic]
Requirements: [Learning objectives, activities, time constraints]
Format: Include objectives, activities, materials needed, and assessment methods
```

**Study guide creation:**
```
I'm a [student level] preparing for [exam/assignment] in [subject].
Create a comprehensive study guide covering [topics].
Include: key concepts, practice questions, and memory techniques.
Format: Organized by topic with clear sections.
```

## Product Management

**Feature analysis:**
```
Task: Analyze [feature/product category] 
Focus: User research findings, competitive landscape, and best practices
Context: [Industry, target market, constraints]
Output: Executive summary with key insights and recommendations
```

**Market research:**
```
Research [product category] in [market/region]
Focus areas: Current trends, leading players, pricing models, user pain points
Deliverable: Market landscape report with opportunities and threats
```

## Financial Analysis

**Sector summary:**
```
Context: [Market sector, e.g., renewable energy, fintech]
Task: Provide a [timeframe, e.g., Q4 2024] performance summary
Data: Include [specific metrics, e.g., market cap changes, major deals]
Format: Executive summary with key trends and outliers
```

**Competitive analysis:**
```
Compare [Company A] vs [Company B] across:
- Financial metrics: [revenue, growth, margins]
- Market position: [market share, competitive advantages]
- Recent developments: [product launches, partnerships]
Timeframe: [period]
Format: Side-by-side comparison with key takeaways
```

## Marketing & Copywriting

**Trend research:**
```
Research current trends in [industry/niche] for [audience]
Focus: [Platform-specific trends, content formats, messaging approaches]
Timeframe: Last [30/60/90] days
Deliverable: Trend report with examples and actionable insights
```

**Competitive positioning:**
```
Analyze how [competitors] are positioning [product/service] in [market]
Focus: Messaging, channels, value propositions, audience targeting
Output: Positioning map with gaps and opportunities
```

## Legal & Compliance

**Regulatory research:**
```
I run a [business type] in [location]
Research: Regulations affecting [industry] businesses
Focus areas: [data protection, consumer rights, tax obligations, etc.]
Deliverable: Compliance checklist with relevant regulations and requirements
```

**Contract review prep:**
```
Context: [Contract type] for [purpose]
Task: Research standard clauses and best practices for [specific terms]
Focus: [Risk areas, negotiation points, industry standards]
Format: Reference guide with examples and red flags
```

## Academic Research

**Literature review:**
```
I'm a [degree level] researching [topic] in [field]
Task: Provide a literature review covering [specific aspects]
Focus: Key studies, methodologies, recent findings, research gaps
Timeframe: [years]
Format: Organized by theme with citations
```

**Research methodology:**
```
Context: [Research question] in [field]
Task: Identify appropriate research methodologies
Include: Study design options, data collection methods, analysis techniques
Focus: [Quantitative/Qualitative/Mixed methods]
Format: Comparison table with pros/cons for each approach
```

## Business Planning

**Strategic plan:**
```
Create a [timeframe] strategic plan for [business context]
Context: [Company stage, industry, constraints]
Include: Goals, initiatives, metrics, resource requirements
Format: Executive summary followed by detailed breakdown by quarter/area
```

**Go-to-market strategy:**
```
Develop a go-to-market strategy for [product/service]
Target market: [audience, geography, segment]
Include: Positioning, channels, pricing approach, launch timeline
Context: [Budget constraints, competition, unique advantages]
Format: Phased rollout plan with success metrics
```

## Content Creation

**Script outline:**
```
Create a [length] [format: video/podcast/presentation] script about [topic]
Audience: [demographics, knowledge level]
Tone: [professional/casual/educational/entertaining]
Structure: [Hook, main points, call-to-action]
Key messages: [3-5 main takeaways]
```

**Email campaign:**
```
Draft an email for [purpose: newsletter/sales/announcement]
Audience: [segment]
Goal: [action you want recipients to take]
Context: [background, previous communications]
Tone: [formal/casual/urgent]
Length: [word count or paragraph count]
```

## Technical Documentation

**API integration guide:**
```
Research [API/service] integration best practices
Focus: Authentication, common endpoints, error handling, rate limits
Use case: [specific integration scenario]
Deliverable: Implementation guide with code examples and gotchas
```

**Technical comparison:**
```
Compare [Technology A] vs [Technology B] for [use case]
Evaluation criteria: Performance, scalability, cost, learning curve, ecosystem
Context: [Team size, existing stack, constraints]
Format: Decision matrix with recommendation
```

## Usage Tips

1. **Replace all bracketed placeholders** with your specific information
2. **Add more context** when your situation has unique constraints
3. **Specify current data needs** explicitly (e.g., "Include 2025 data" or "Use latest market reports")
4. **Request sources** when verification matters: "Include citations for key claims"
5. **Iterate** - If results aren't quite right, refine your specifics and resubmit
